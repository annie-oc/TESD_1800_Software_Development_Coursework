// Author: Annie O'Connor
// Date: 9.4.26

import java.util.Date;

public abstract class GeometricObject {
   private String color = "white";
   private boolean filled;
   private java.util.Date dateCreated;

   protected GeometricObject() {
       dateCreated = new Date();
   }

   protected GeometricObject(String color, boolean filled) {
       dateCreated = new Date();
       this.color = color;
       this.filled = filled;
   }

   public String getColor() {
       return color;
   }

   public void setColor(String color) {
       this.color = color;
   }

   public boolean isFilled() {
       return filled;
   }

   public void setFilled(boolean filled) {
       this.filled = filled;
   }

   public java.util.Date getDateCreated() {
       return dateCreated;
   }

   @Override
   public String toString() {
       return "created on " + dateCreated + "\ncolor: " + color
               + " and filled: " + filled;
   }
}
