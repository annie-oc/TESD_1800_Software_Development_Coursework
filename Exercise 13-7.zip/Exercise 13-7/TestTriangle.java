// Author: Annie O'Connor
// Date: 9.4.26

import java.util.Scanner;

public class TestTriangle {
   public static void main(String[] args) {
       Scanner input = new Scanner(System.in);

       GeometricObject[] geometricObjects = new GeometricObject[5];

       for (int i = 0; i < geometricObjects.length; i++) {
        System.out.print("Enter three sides for Triangle " 
                    + (i + 1) + ". ");
        
        double side1 = input.nextDouble();
        double side2 = input.nextDouble();
        double side3 = input.nextDouble();

        geometricObjects[i] = new Triangle(side1, side2, side3);

        System.out.print("Enter the color: ");
        String color = input.next();

        System.out.print("Is the triangle filled? (true or false): ");
        boolean filled = input.nextBoolean();

        geometricObjects[i].setColor(color);
        geometricObjects[i].setFilled(filled);

       }

       System.out.println();

       for (int i = 0; i < geometricObjects.length; i++) {
        System.out.println("Triangle " + (i + 1));

        System.out.println("Area: "
                + ((Triangle) geometricObjects[i]).getArea());

                if (geometricObjects[i] instanceof Colorable) {
                    ((Colorable) geometricObjects[i]).howtoColor();
                }

                System.out.println();
       }
   }
}