// Author: Annie O'Connor
// Date: 9.4.26

public interface Colorable {
    void howToColor();
}